## Module <odoo-debrand>

#### 01.01.2019
#### Version 12.0.1.0.0
#### ADD
Initial Commit for odoo-debrand

#### 10.02.2019
#### Version 12.0.1.0.1
#### FIX
Bug Fixed, Issue in New Db Creation

#### 25.09.2019
#### Version 12.0.1.1.1
#### FIX
Bug Fixed, Icon in database manager.
